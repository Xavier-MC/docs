---
sidebar_position: 1
---

# 申请假人

:::note

[点我申请](https://flowus.cn/form/1aebfb23-6b05-4bac-b045-6fc33ed45bf7?code=L78AAG)
申请前请务必看完假人使用规定。

:::